NEXORA — BACKEND RAILWAY

CONTENU
- server.js : serveur API NEXORA
- package.json : dépendances et commande de démarrage
- .env.example : exemple des variables nécessaires

DÉPLOIEMENT
1. Ajoute les fichiers server.js, package.json et .env.example à la racine du dépôt GitHub NEXORA.
2. Railway doit être connecté à ce dépôt GitHub.
3. Railway détectera Node.js et lancera automatiquement la commande : npm start
4. Dans Railway > Variables, ajoute OPENAI_API_KEY et OPENAI_MODEL.
5. Ne partage jamais la valeur de OPENAI_API_KEY. Pour la création et la gestion d'un compte/API, demande l'aide d'un parent ou tuteur.
6. Après le déploiement, teste l'adresse publique avec /api/health.

IMPORTANT
- Le fichier .env.example est un modèle vide : il ne contient aucune clé secrète.
- PostgreSQL n'est pas nécessaire pour faire fonctionner la route de chat de base.
- Ce backend ne stocke pas les conversations dans une base de données.
