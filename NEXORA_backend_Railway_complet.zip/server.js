import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

app.get("/", (_req, res) => {
  res.json({ name: "NEXORA API", status: "online" });
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "NEXORA API" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "Le serveur IA n'est pas encore configuré." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const latestUserMessage = [...messages].reverse().find(m => m?.role === "user");

    if (!latestUserMessage?.content) {
      return res.status(400).json({ error: "Aucun message utilisateur reçu." });
    }

    const mode = String(req.body?.mode || "chat");
    const effort = String(req.body?.effort || "medium");
    const instructions = [
      "Tu es NEXORA, un assistant IA utile, clair et naturel.",
      "Réponds dans la langue utilisée par l'utilisateur.",
      "Ne révèle jamais de raisonnement privé détaillé. Donne seulement une explication ou un résumé utile.",
      `Mode demandé : ${mode}. Niveau d'effort demandé : ${effort}.`
    ].join("\n");

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      instructions,
      input: messages.map(m => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: String(m.content ?? "")
      }))
    });

    res.json({ reply: response.output_text || "Je n'ai pas pu produire de réponse." });
  } catch (error) {
    console.error("Erreur /api/chat:", error?.message || error);
    res.status(500).json({ error: "Erreur du serveur IA. Vérifie les journaux Railway." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, "0.0.0.0", () => {
  console.log(`NEXORA API démarrée sur le port ${port}`);
});
